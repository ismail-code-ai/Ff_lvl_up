# FreeFire BR Bot — Web Panel

Converted the original `lvl.py` CLI bot into a **web control panel** (FastAPI + WebSocket)
with a modern dark UI. Add multiple accounts (UID / password / region), auto-fetch each
account's details, and start/stop BR matches with live status (`Matchmaking` → `In Game`).

---

## 1. What was fixed (auto BR match)

The original code kept a single **global** `ACCOUNT_REGION` (default `"ME"`) and used it
inside `functional_br()` when sending the start-match packet:

```python
# OLD (bug) — always used the global region, ignoring the account's real region
async def send_start_match():
    current_region = ACCOUNT_REGION
    await start_game_battle_royale(current_region, client_version, writer, ...)
```

If the account's real region (returned by `MajorLogin`) did **not** match the global
`ACCOUNT_REGION`, the start-match packet was built with the **wrong region prefix**
(`0319` = ME, `0314` = IND/BD, `0315` = others) and the match server silently ignored it —
so **auto BR never started**.

### Fix
* `send_start_match()` now uses the **per-account region** (`account_region`), which comes
  from the account's own login response.
* `version_config()`, `process_account_uid_pass()` and the keep-alive are all
  **region-parameterised** instead of relying on the global.
* Each account now runs in its **own session/task**, so multiple IDs with **different
  regions** work at the same time.
* Added a persistent session: on drop it **auto re-logs-in and reconnects** (auto BR)
  until you press **Stop**.

---

## 2. Features

| Feature | Description |
|---|---|
| Add account | Enter **UID**, **Password**, **Region** → account is saved and its profile is fetched automatically |
| Multiple IDs | Add as many accounts as you want; each runs independently |
| Auto details | On add, logs in with UID/password and shows **Name, UID, Level, Exp, Region** |
| Start Match | Green **Start Match** button → begins BR matchmaking for that account |
| Live status | Top bar + per-card badge: `Logging in` → `Ready` → **`Matchmaking`** → **`In Game`** |
| Stop / Refresh / Remove | Stop the session, re-fetch details, or delete the account |
| Live logs | Per-account console streamed over WebSocket |

---

## 3. Project layout

```
ff_web/
├── botcore.py          # protocol + login + match engine (from lvl.py, region fixed)
├── manager.py          # account manager, login, match control, status
├── server.py           # FastAPI app (REST + WebSocket + static)
├── message_ids.py      # message id → name map
├── thunderFF_pb2.py    # protobuf definitions
├── static/
│   ├── index.html      # panel UI
│   ├── style.css       # dark theme
│   └── app.js          # REST + WebSocket client
├── data/accounts.json  # persisted accounts (auto-created)
├── requirements.txt
├── run.sh
└── test_flow.py        # offline flow test (mocked network)
```

---

## 4. Install & run

```bash
cd ff_web
pip install -r requirements.txt

# start the panel
python3 -m uvicorn server:app --host 0.0.0.0 --port 8000
# or
./run.sh
```

Then open **http://localhost:8000** in your browser.

---

## 5. API (optional, for automation)

| Method | Path | Body | Purpose |
|---|---|---|---|
| GET | `/api/accounts` | – | list accounts + status |
| POST | `/api/accounts` | `{uid,password,region}` | add + fetch details |
| POST | `/api/accounts/{uid}/login` | – | re-fetch details |
| POST | `/api/accounts/{uid}/start` | – | start BR match |
| POST | `/api/accounts/{uid}/stop` | – | stop BR match |
| DELETE | `/api/accounts/{uid}` | – | remove account |
| WS | `/ws` | – | live status/log stream |

---

## 6. Notes

* The account's **real region** (from the login response) is authoritative; the region you
  pick in the form is used as a fallback and for the version/region API call.
* If login fails, the card shows an `Error` badge with the reason (wrong UID/password or
  server error).
* Make sure `PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python` is set (the run script does it)
  so the `protobuf_decoder` parser works.
