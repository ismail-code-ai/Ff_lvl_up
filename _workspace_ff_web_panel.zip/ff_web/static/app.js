/* FreeFire BR Bot Panel - frontend logic */
const state = { accounts: {}, regions: [] };

const $ = (id) => document.getElementById(id);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
};

/* ------------------------- toast ------------------------- */
let toastTimer = null;
function toast(msg, kind) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast " + (kind || "")), 2600);
}

/* ------------------------- api helpers ------------------------- */
async function api(path, opts) {
  const res = await fetch(path, Object.assign({ headers: { "Content-Type": "application/json" } }, opts));
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.detail) || res.statusText);
  return data;
}

/* ------------------------- status helpers ------------------------- */
const STATUS_LABEL = {
  idle: "Idle",
  logging_in: "Logging in",
  ready: "Ready",
  matchmaking: "Matchmaking",
  in_game: "In Game",
  error: "Error",
  stopped: "Stopped",
};

function badge(status) {
  const s = status || "idle";
  return `<span class="badge ${s}"><span class="dot"></span>${STATUS_LABEL[s] || s}</span>`;
}

function updateGlobalStatus() {
  const list = Object.values(state.accounts);
  let g = "Idle", cls = "";
  if (list.some((a) => a.status === "in_game")) { g = "In Game"; }
  else if (list.some((a) => a.status === "matchmaking")) { g = "Matchmaking"; }
  else if (list.some((a) => a.status === "logging_in")) { g = "Logging in"; }
  else if (list.some((a) => a.status === "ready")) { g = "Ready"; }
  else if (list.length) { g = "Idle"; }
  const node = $("globalStatus");
  node.textContent = g;
  node.style.color =
    g === "In Game" ? "var(--green)" :
    g === "Matchmaking" ? "var(--blue)" :
    g === "Logging in" ? "var(--amber)" : "var(--text)";
}

/* ------------------------- render ------------------------- */
function render() {
  const wrap = $("accounts");
  const list = Object.values(state.accounts);
  $("empty").style.display = list.length ? "none" : "block";
  wrap.innerHTML = "";

  list.forEach((a) => {
    const card = el("div", "card " + (a.status || ""));
    const running = a.running || a.status === "matchmaking" || a.status === "in_game";

    const logsHtml = (a.logs || [])
      .map((l) => {
        const m = (l.msg || "").replace(/</g, "&lt;");
        const cls = m.includes("[+]") ? "ok" : (m.includes("[-]") || m.includes("[!]")) ? "err" : "";
        return `<div class="l ${cls}">${m}</div>`;
      })
      .join("");

    card.innerHTML = `
      <div class="card-head">
        <div class="card-title">
          <span class="name">${(a.name || "Unknown Player").replace(/</g, "&lt;")}</span>
          <span class="uid">UID: ${a.uid}${a.account_id ? " &middot; ID: " + a.account_id : ""}</span>
        </div>
        ${badge(a.status)}
      </div>
      <div class="stats">
        <div class="stat"><div class="k">Level</div><div class="v">${a.level != null ? a.level : "—"}</div></div>
        <div class="stat"><div class="k">Exp</div><div class="v">${a.exp != null ? a.exp : "—"}</div></div>
        <div class="stat"><div class="k">Region</div><div class="v">${a.region || "—"}</div></div>
      </div>
      <div class="card-actions">
        ${running
          ? `<button class="btn-stop" data-act="stop" data-uid="${a.uid}">■ Stop Match</button>`
          : `<button class="btn-start" data-act="start" data-uid="${a.uid}">▶ Start Match</button>`}
        <button class="btn-ghost" data-act="login" data-uid="${a.uid}" title="Re-fetch details">↻ Refresh</button>
        <span class="spacer"></span>
        <button class="btn-ghost" data-act="remove" data-uid="${a.uid}" title="Remove account">✕</button>
      </div>
      ${a.error ? `<div class="err">${(a.error || "").replace(/</g, "&lt;")}</div>` : ""}
      ${logsHtml ? `<div class="logs">${logsHtml}</div>` : ""}
    `;
    wrap.appendChild(card);
  });

  // keep log boxes scrolled to bottom
  wrap.querySelectorAll(".logs").forEach((b) => (b.scrollTop = b.scrollHeight));
  updateGlobalStatus();
}

/* ------------------------- actions ------------------------- */
async function addAccount(e) {
  e.preventDefault();
  const uid = $("uid").value.trim();
  const password = $("password").value;
  const region = $("region").value;
  if (!uid || !password) return;
  const btn = $("addBtn");
  btn.disabled = true;
  btn.textContent = "Adding...";
  try {
    await api("/api/accounts", { method: "POST", body: JSON.stringify({ uid, password, region }) });
    $("uid").value = "";
    $("password").value = "";
    toast("Account added", "ok");
  } catch (err) {
    toast("Add failed: " + err.message, "err");
  } finally {
    btn.disabled = false;
    btn.textContent = "Add Account";
  }
}

async function onCardClick(e) {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const uid = btn.dataset.uid;
  const act = btn.dataset.act;
  btn.disabled = true;
  try {
    if (act === "start") {
      toast("Starting BR match...", "ok");
      await api(`/api/accounts/${encodeURIComponent(uid)}/start`, { method: "POST" });
    } else if (act === "stop") {
      await api(`/api/accounts/${encodeURIComponent(uid)}/stop`, { method: "POST" });
      toast("Stopped");
    } else if (act === "login") {
      toast("Refreshing details...");
      await api(`/api/accounts/${encodeURIComponent(uid)}/login`, { method: "POST" });
    } else if (act === "remove") {
      if (!confirm("Remove this account?")) { btn.disabled = false; return; }
      await api(`/api/accounts/${encodeURIComponent(uid)}`, { method: "DELETE" });
      delete state.accounts[uid];
      render();
      toast("Removed");
    }
  } catch (err) {
    toast("Error: " + err.message, "err");
  } finally {
    btn.disabled = false;
  }
}

/* ------------------------- websocket ------------------------- */
function connectWS() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);

  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }

    if (msg.type === "snapshot") {
      state.accounts = {};
      (msg.accounts || []).forEach((a) => (state.accounts[a.uid] = a));
      render();
    } else if (msg.type === "account") {
      state.accounts[msg.account.uid] = msg.account;
      render();
    } else if (msg.type === "status") {
      const a = state.accounts[msg.uid];
      if (a) { a.status = msg.status; a.running = ["matchmaking", "in_game"].includes(msg.status); render(); }
    } else if (msg.type === "log") {
      const a = state.accounts[msg.uid];
      if (a) {
        a.logs = a.logs || [];
        a.logs.push({ t: msg.t, msg: msg.msg });
        if (a.logs.length > 60) a.logs = a.logs.slice(-60);
        render();
      }
    } else if (msg.type === "removed") {
      delete state.accounts[msg.uid];
      render();
    }
  };

  ws.onclose = () => setTimeout(connectWS, 1500);
  ws.onerror = () => ws.close();
}

/* ------------------------- init ------------------------- */
async function init() {
  try {
    const r = await api("/api/regions");
    state.regions = r.regions || [];
    const sel = $("region");
    sel.innerHTML = state.regions.map((x) => `<option value="${x}"${x === "ME" ? " selected" : ""}>${x}</option>`).join("");
  } catch (e) {
    $("region").innerHTML = '<option value="ME">ME</option>';
  }

  try {
    const a = await api("/api/accounts");
    (a.accounts || []).forEach((acc) => (state.accounts[acc.uid] = acc));
    render();
  } catch (e) {}

  $("addForm").addEventListener("submit", addAccount);
  $("accounts").addEventListener("click", onCardClick);
  connectWS();
}

document.addEventListener("DOMContentLoaded", init);
