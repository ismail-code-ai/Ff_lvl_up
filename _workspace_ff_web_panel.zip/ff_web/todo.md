# TODO - FreeFire BR Bot Web Panel

## Analysis
- [x] Extract and read UDP.zip (lvl.py, message_ids.py, thunderFF_pb2.py)
- [x] Identify auto-BR bug (global ACCOUNT_REGION used instead of per-account region in send_start_match)
- [x] Verify dependencies install & modules import

## Backend - Bot Core
- [x] Copy lvl.py -> botcore.py (LF endings), strip CLI main/prompts
- [x] Parameterize region (version_config, process_account_uid_pass, start match, keepalive)
- [x] Add status/log callbacks + stop_event to functional_br & play_game
- [x] Fix send_start_match to use account_region (auto BR fix)

## Backend - Manager
- [x] AccountManager: add/list/remove accounts, persist JSON
- [x] login_account -> fetch name, uid, lvl, exp
- [x] start_match / stop_match per account with status tracking
- [x] Persistent session with auto re-login/reconnect
- [x] WebSocket broadcast of status/log updates

## Backend - Server
- [x] FastAPI app: static serving + REST endpoints + WS
- [x] requirements.txt + run script

## Frontend
- [x] style.css (modern dark panel)
- [x] index.html (add account form, account cards, top status)
- [x] app.js (REST + WS, Start Match button, status badges)

## Test & Deliver
- [x] Run server, smoke-test endpoints (add account, WS, UI render)
- [ ] Expose port / provide preview URL
- [ ] Package deliverables
