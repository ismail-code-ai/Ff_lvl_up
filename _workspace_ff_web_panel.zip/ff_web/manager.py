# -*- coding: utf-8 -*-
"""
Account manager for the FreeFire BR web panel.

Holds accounts, performs login/profile fetch, and controls the BR match
session per account with live status reporting (idle -> matchmaking -> in_game).
"""
import asyncio
import json
import os
import time
from typing import Dict, List, Optional, Callable, Awaitable

import botcore

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DATA_FILE = os.path.join(DATA_DIR, "accounts.json")

VALID_REGIONS = ["ME", "IND", "SG", "TH", "PH", "VN", "MY", "ID", "HK", "TW",
                 "BD", "PK", "CIS", "BR", "NA", "SAC", "EUROPE"]

# statuses
ST_IDLE = "idle"
ST_LOGGING_IN = "logging_in"
ST_READY = "ready"
ST_MATCHMAKING = "matchmaking"
ST_IN_GAME = "in_game"
ST_ERROR = "error"
ST_STOPPED = "stopped"


class AccountSession:
    def __init__(self, uid: str, password: str, region: str = "ME"):
        self.uid = str(uid).strip()
        self.password = password
        self.region = (region or "ME").upper()
        self.account_data: Optional[Dict] = None
        self.status = ST_IDLE
        self.error: Optional[str] = None
        self.logs: List[Dict] = []
        self.task: Optional[asyncio.Task] = None
        self.stop_event: Optional[asyncio.Event] = None
        self.last_update = time.time()

    def public(self) -> Dict:
        ad = self.account_data or {}
        return {
            "uid": self.uid,
            "name": ad.get("nickname") or "",
            "account_id": str(ad.get("account_id") or ""),
            "level": ad.get("level"),
            "exp": ad.get("exp"),
            "region": ad.get("region") or self.region,
            "status": self.status,
            "error": self.error,
            "running": bool(self.task and not self.task.done()),
            "logs": self.logs[-60:],
        }


class AccountManager:
    def __init__(self):
        self.accounts: Dict[str, AccountSession] = {}
        self._listeners: List[Callable[[Dict], Awaitable[None]]] = []
        self._load()

    # ---------------- persistence ----------------
    def _load(self):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for a in data:
                uid = str(a.get("uid", "")).strip()
                if not uid:
                    continue
                s = AccountSession(uid, a.get("password", ""), a.get("region", "ME"))
                self.accounts[uid] = s
        except Exception:
            pass

    def _save(self):
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            payload = [
                {"uid": s.uid, "password": s.password, "region": s.region}
                for s in self.accounts.values()
            ]
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            pass

    # ---------------- listeners / broadcast ----------------
    def add_listener(self, cb):
        self._listeners.append(cb)

    def remove_listener(self, cb):
        try:
            self._listeners.remove(cb)
        except ValueError:
            pass

    async def broadcast(self, msg: Dict):
        for cb in list(self._listeners):
            try:
                await cb(msg)
            except Exception:
                pass

    async def _emit_account(self, session: AccountSession):
        await self.broadcast({"type": "account", "account": session.public()})

    def _log(self, session: AccountSession, msg: str):
        entry = {"t": time.time(), "msg": msg}
        session.logs.append(entry)
        if len(session.logs) > 300:
            session.logs = session.logs[-300:]
        # avoid spamming the socket with the very chatty debug lines
        if "[DEBUG]" in msg:
            return
        try:
            asyncio.get_running_loop().create_task(
                self.broadcast({"type": "log", "uid": session.uid, "msg": msg, "t": entry["t"]})
            )
        except Exception:
            pass

    async def _set_status(self, session: AccountSession, status: str):
        if session.status != status:
            session.status = status
            session.last_update = time.time()
            await self.broadcast({"type": "status", "uid": session.uid, "status": status})

    # ---------------- account CRUD ----------------
    def list_public(self) -> List[Dict]:
        return [s.public() for s in self.accounts.values()]

    def get(self, uid: str) -> Optional[AccountSession]:
        return self.accounts.get(str(uid).strip())

    async def add_account(self, uid: str, password: str, region: str = "ME") -> Dict:
        uid = str(uid).strip()
        if not uid:
            raise ValueError("UID is required")
        if not password:
            raise ValueError("Password is required")
        region = (region or "ME").upper()
        if region not in VALID_REGIONS:
            region = "ME"

        session = self.accounts.get(uid)
        if session is None:
            session = AccountSession(uid, password, region)
            self.accounts[uid] = session
        else:
            session.password = password
            session.region = region
        self._save()

        await self._emit_account(session)
        # fetch details (login) right away
        await self.login_account(uid)
        return session.public()

    async def remove_account(self, uid: str):
        session = self.accounts.get(str(uid).strip())
        if not session:
            return
        await self.stop_match(uid)
        self.accounts.pop(session.uid, None)
        self._save()
        await self.broadcast({"type": "removed", "uid": session.uid})

    async def login_account(self, uid: str) -> Dict:
        session = self.accounts.get(str(uid).strip())
        if not session:
            raise ValueError("Account not found")
        if session.task and not session.task.done():
            # already running a session
            return session.public()

        session.error = None
        await self._set_status(session, ST_LOGGING_IN)
        self._log(session, f"[*] Fetching profile for UID {session.uid} ...")
        try:
            data = await botcore.process_account_uid_pass(
                session.uid, session.password, session.region
            )
        except Exception as e:
            data = None
            self._log(session, f"[-] Login error: {e}")

        if not data:
            session.error = "Login failed (wrong UID/password or server error)"
            await self._set_status(session, ST_ERROR)
            self._log(session, f"[-] Login failed for UID {session.uid}")
            await self._emit_account(session)
            return session.public()

        session.account_data = data
        session.error = None
        await self._set_status(session, ST_READY)
        self._log(
            session,
            f"[+] Login OK | {data.get('nickname')} | UID {data.get('account_id')} "
            f"| Lvl {data.get('level')} | Exp {data.get('exp')} | Region {data.get('region')}",
        )
        await self._emit_account(session)
        return session.public()

    # ---------------- match control ----------------
    async def start_match(self, uid: str) -> Dict:
        session = self.accounts.get(str(uid).strip())
        if not session:
            raise ValueError("Account not found")
        if session.task and not session.task.done():
            return session.public()  # already running

        # login if we don't have a valid session yet
        if not session.account_data:
            await self.login_account(uid)
            if not session.account_data:
                return session.public()

        session.stop_event = asyncio.Event()
        session.task = asyncio.create_task(self._run_session(session))
        await self._emit_account(session)
        return session.public()

    async def stop_match(self, uid: str) -> Dict:
        session = self.accounts.get(str(uid).strip())
        if not session:
            raise ValueError("Account not found")
        if session.stop_event:
            session.stop_event.set()
        if session.task and not session.task.done():
            session.task.cancel()
            try:
                await session.task
            except (asyncio.CancelledError, Exception):
                pass
        session.task = None
        await self._set_status(session, ST_READY if session.account_data else ST_IDLE)
        await self._emit_account(session)
        return session.public()

    async def _run_session(self, session: AccountSession):
        """Persistent session: keeps playing BR matches, auto re-logs in on drop,
        until the user presses Stop."""
        while True:
            if session.stop_event and session.stop_event.is_set():
                break
            try:
                retry = await self._run_once(session)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                session.error = str(e)
                self._log(session, f"[-] Session error: {e}")
                retry = True

            if session.stop_event and session.stop_event.is_set():
                break
            if not retry:
                break

            # Session dropped on its own -> reconnect automatically (auto BR)
            self._log(session, "[!] Session dropped. Reconnecting in 3s...")
            await self._set_status(session, ST_LOGGING_IN)
            await asyncio.sleep(3)
            try:
                data = await botcore.process_account_uid_pass(
                    session.uid, session.password, session.region
                )
                if data:
                    session.account_data = data
                    session.error = None
                    await self._emit_account(session)
            except Exception:
                pass

        await self._set_status(session, ST_READY if session.account_data else ST_IDLE)
        await self._emit_account(session)

    async def _run_once(self, session: AccountSession):
        ad = session.account_data
        reg = ad.get("region") or session.region
        acc_id = str(ad.get("account_id"))
        func_addr = ad.get("functional_addrs")
        info_addr = ad.get("informational_addrs")

        info_task = None
        exp_task = None
        try:
            if not func_addr or ":" not in str(func_addr):
                session.error = "No match server address returned by login"
                await self._set_status(session, ST_ERROR)
                self._log(session, f"[-] {session.error} (functional_addrs missing)")
                await self._emit_account(session)
                return False

            tcp_online = await botcore.build_tcp_startup_packet(
                ad["account_id"], ad["token"], ad["server_time"],
                ad["aes_ak"], ad["iv_i"], region=reg, typ="OnLine",
            )
            tcp_chat = await botcore.build_tcp_startup_packet(
                ad["account_id"], ad["token"], ad["server_time"],
                ad["aes_ak"], ad["iv_i"], region=reg, typ="ChaT",
            )

            if info_addr and ":" in str(info_addr):
                info_task = asyncio.create_task(
                    botcore.informational(
                        info_addr, tcp_chat, ad["aes_ak"], ad["iv_i"],
                        region=reg, account_id=acc_id,
                    )
                )

            exp_task = asyncio.create_task(self._exp_refresher(session))

            async def status_cb(st):
                if st == "connected":
                    st = ST_MATCHMAKING
                await self._set_status(session, st)
                await self._emit_account(session)

            def log_cb(msg):
                self._log(session, msg)

            await botcore.functional_br(
                func_addr,
                tcp_online,
                reg,
                ad["client_version"],
                ad["aes_ak"],
                ad["iv_i"],
                account_id=acc_id,
                account_data=ad,
                status_cb=status_cb,
                log_cb=log_cb,
                stop_event=session.stop_event,
                single_match=False,
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            session.error = str(e)
            self._log(session, f"[-] Session error: {e}")
        finally:
            for t in (info_task, exp_task):
                if t and not t.done():
                    t.cancel()
            for t in (info_task, exp_task):
                if t:
                    try:
                        await t
                    except (asyncio.CancelledError, Exception):
                        pass
        return True

    async def _exp_refresher(self, session: AccountSession):
        while True:
            await asyncio.sleep(120)
            try:
                await botcore.refresh_account_profile(session.account_data)
                await self._emit_account(session)
            except Exception:
                pass

    async def shutdown(self):
        for uid in list(self.accounts.keys()):
            try:
                await self.stop_match(uid)
            except Exception:
                pass
