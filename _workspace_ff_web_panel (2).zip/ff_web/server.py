# -*- coding: utf-8 -*-
"""
FreeFire BR Bot - Web Panel server (FastAPI).

Run:  python server.py   (or: uvicorn server:app --host 0.0.0.0 --port 8000)
"""
import sys
import asyncio

# ---------------------------------------------------------------------------
# Windows compatibility (must run BEFORE any event loop is created):
# the default ProactorEventLoop does not implement loop.sock_sendto()/
# loop.sock_recvfrom(), which the UDP match session needs. Force a Selector loop.
# ---------------------------------------------------------------------------
if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    except Exception:
        pass

import os

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from manager import AccountManager, VALID_REGIONS

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = FastAPI(title="FreeFire BR Bot Panel")
manager = AccountManager()

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# ----------------------------- models -----------------------------
class AddAccountReq(BaseModel):
    uid: str
    password: str
    region: str = "ME"


# ----------------------------- pages ------------------------------
@app.get("/")
async def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.get("/favicon.ico")
async def favicon():
    return JSONResponse({}, status_code=204)


# ----------------------------- API --------------------------------
@app.get("/api/regions")
async def regions():
    return {"regions": VALID_REGIONS}


@app.get("/api/accounts")
async def list_accounts():
    return {"accounts": manager.list_public()}


@app.post("/api/accounts")
async def add_account(req: AddAccountReq):
    try:
        acc = await manager.add_account(req.uid, req.password, req.region)
        return {"ok": True, "account": acc}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/accounts/{uid}")
async def remove_account(uid: str):
    if not manager.get(uid):
        raise HTTPException(status_code=404, detail="Account not found")
    await manager.remove_account(uid)
    return {"ok": True}


@app.post("/api/accounts/{uid}/login")
async def login_account(uid: str):
    if not manager.get(uid):
        raise HTTPException(status_code=404, detail="Account not found")
    try:
        acc = await manager.login_account(uid)
        return {"ok": True, "account": acc}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/accounts/{uid}/start")
async def start_match(uid: str):
    if not manager.get(uid):
        raise HTTPException(status_code=404, detail="Account not found")
    try:
        acc = await manager.start_match(uid)
        return {"ok": True, "account": acc}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/accounts/{uid}/stop")
async def stop_match(uid: str):
    if not manager.get(uid):
        raise HTTPException(status_code=404, detail="Account not found")
    try:
        acc = await manager.stop_match(uid)
        return {"ok": True, "account": acc}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ----------------------------- websocket --------------------------
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    queue: asyncio.Queue = asyncio.Queue()

    async def listener(msg):
        await queue.put(msg)

    manager.add_listener(listener)
    try:
        await ws.send_json({"type": "snapshot", "accounts": manager.list_public()})
        while True:
            msg = await queue.get()
            await ws.send_json(msg)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        manager.remove_listener(listener)


@app.on_event("shutdown")
async def _shutdown():
    await manager.shutdown()


if __name__ == "__main__":
    import uvicorn
    # loop="asyncio" keeps our SelectorEventLoop policy (needed for UDP on Windows)
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info", loop="asyncio")
