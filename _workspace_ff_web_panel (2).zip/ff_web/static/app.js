/* FreeFire BR Bot Panel - frontend logic */
const state = { accounts: {}, regions: [] };

const $ = (id) => document.getElementById(id);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
};
const esc = (s) => String(s == null ? "" : s).replace(/</g, "&lt;").replace(/>/g, "&gt;");

/* ------------------------- toast ------------------------- */
let toastTimer = null;
function toast(msg, kind) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast " + (kind || "")), 2600);
}

/* ------------------------- api helpers ------------------------- */
async function api(path, opts) {
  const res = await fetch(path, Object.assign({ headers: { "Content-Type": "application/json" } }, opts));
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.detail) || res.statusText);
  return data;
}

/* ------------------------- status helpers ------------------------- */
const STATUS_LABEL = {
  idle: "Idle",
  logging_in: "Logging in",
  ready: "Ready",
  matchmaking: "Matchmaking",
  in_game: "In Game",
  error: "Error",
  stopped: "Stopped",
};

function badge(status) {
  const s = status || "idle";
  return `<span class="badge ${s}"><span class="dot"></span>${STATUS_LABEL[s] || s}</span>`;
}

function updateGlobalStatus() {
  const list = Object.values(state.accounts);
  let g = "Idle";
  if (list.some((a) => a.status === "in_game")) { g = "In Game"; }
  else if (list.some((a) => a.status === "matchmaking")) { g = "Matchmaking"; }
  else if (list.some((a) => a.status === "logging_in")) { g = "Logging in"; }
  else if (list.some((a) => a.status === "ready")) { g = "Ready"; }
  else if (list.length) { g = "Idle"; }
  const node = $("globalStatus");
  node.textContent = g;
  node.style.color =
    g === "In Game" ? "var(--green)" :
    g === "Matchmaking" ? "var(--blue)" :
    g === "Logging in" ? "var(--amber)" : "var(--text)";
}

/* ------------------------- duration / timer ------------------------- */
function fmtDuration(startEpoch) {
  if (!startEpoch) return "\u2014";
  const secs = Math.max(0, Math.floor(Date.now() / 1000 - Number(startEpoch)));
  const h = String(Math.floor(secs / 3600)).padStart(2, "0");
  const m = String(Math.floor((secs % 3600) / 60)).padStart(2, "0");
  const s = String(secs % 60).padStart(2, "0");
  return `${h}:${m}:${s}`;
}

// live-update every match timer once per second
setInterval(() => {
  document.querySelectorAll(".v.timer[data-timer-start]").forEach((n) => {
    const v = n.getAttribute("data-timer-start");
    if (v) n.textContent = fmtDuration(v);
  });
}, 1000);

/* ------------------------- confirm modal ------------------------- */
const modal = { onConfirm: null };

function openConfirm(opts) {
  $("modalTitle").textContent = opts.title || "Are you sure?";
  $("modalText").innerHTML = opts.text || "";
  const ic = $("modalIcon");
  ic.textContent = opts.icon || "!";
  ic.className = "modal-icon" + (opts.warn ? " warn" : "");
  $("modalConfirm").textContent = opts.confirmText || "Confirm";
  modal.onConfirm = opts.onConfirm || null;
  const ov = $("modalOverlay");
  ov.classList.add("show");
  ov.setAttribute("aria-hidden", "false");
}

function closeConfirm() {
  const ov = $("modalOverlay");
  ov.classList.remove("show");
  ov.setAttribute("aria-hidden", "true");
  modal.onConfirm = null;
}

function initModal() {
  $("modalCancel").addEventListener("click", closeConfirm);
  $("modalOverlay").addEventListener("click", (e) => {
    if (e.target === $("modalOverlay")) closeConfirm();
  });
  $("modalConfirm").addEventListener("click", async () => {
    const fn = modal.onConfirm;
    closeConfirm();
    if (fn) await fn();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && $("modalOverlay").classList.contains("show")) closeConfirm();
  });
}

/* ------------------------- render ------------------------- */
function render() {
  const wrap = $("accounts");
  const list = Object.values(state.accounts);
  $("empty").style.display = list.length ? "none" : "block";
  wrap.innerHTML = "";

  list.forEach((a) => {
    const card = el("div", "card " + (a.status || ""));
    const running = a.running || a.status === "matchmaking" || a.status === "in_game";

    const logsHtml = (a.logs || [])
      .map((l) => {
        const m = esc(l.msg || "");
        const cls = (l.msg || "").includes("[+]") ? "ok"
          : ((l.msg || "").includes("[-]") || (l.msg || "").includes("[!]")) ? "err" : "";
        return `<div class="l ${cls}">${m}</div>`;
      })
      .join("");

    const timerVal = a.match_started_at ? fmtDuration(a.match_started_at) : "\u2014";
    const expGain = (a.exp_gain != null) ? (a.exp_gain > 0 ? "+" + a.exp_gain : String(a.exp_gain)) : "\u2014";

    card.innerHTML = `
      <div class="card-head">
        <div class="card-title">
          <span class="name">${esc(a.name || "Unknown Player")}</span>
          <span class="uid">UID: ${esc(a.uid)}${a.account_id ? " &middot; ID: " + esc(a.account_id) : ""}</span>
        </div>
        ${badge(a.status)}
      </div>
      <div class="stats">
        <div class="stat"><div class="k">Level</div><div class="v">${a.level != null ? a.level : "\u2014"}</div></div>
        <div class="stat"><div class="k">Exp</div><div class="v">${a.exp != null ? a.exp : "\u2014"}</div></div>
        <div class="stat"><div class="k">Exp Gain</div><div class="v gain">${expGain}</div></div>
        <div class="stat"><div class="k">Region</div><div class="v">${esc(a.region || "\u2014")}</div></div>
        <div class="stat"><div class="k">Total Matches</div><div class="v">${a.total_matches != null ? a.total_matches : 0}</div></div>
        <div class="stat"><div class="k">Match Time</div><div class="v timer" data-timer-start="${a.match_started_at || ""}">${timerVal}</div></div>
      </div>
      <div class="card-actions">
        ${running
          ? `<button class="btn-stop" data-act="stop" data-uid="${esc(a.uid)}">\u25a0 Stop Match</button>`
          : `<button class="btn-start" data-act="start" data-uid="${esc(a.uid)}">\u25b6 Start Match</button>`}
        <button class="btn-ghost" data-act="login" data-uid="${esc(a.uid)}" title="Re-fetch details">\u21bb Refresh</button>
        <span class="spacer"></span>
        <button class="btn-ghost" data-act="remove" data-uid="${esc(a.uid)}" title="Remove account">\u2715</button>
      </div>
      ${a.error ? `<div class="err">${esc(a.error)}</div>` : ""}
      ${logsHtml ? `<div class="logs">${logsHtml}</div>` : ""}
    `;
    wrap.appendChild(card);
  });

  // keep log boxes scrolled to bottom
  wrap.querySelectorAll(".logs").forEach((b) => (b.scrollTop = b.scrollHeight));
  updateGlobalStatus();
}

/* ------------------------- actions ------------------------- */
async function addAccount(e) {
  e.preventDefault();
  const uid = $("uid").value.trim();
  const password = $("password").value;
  const region = $("region").value;
  if (!uid || !password) return;
  const btn = $("addBtn");
  btn.disabled = true;
  btn.textContent = "Adding...";
  try {
    await api("/api/accounts", { method: "POST", body: JSON.stringify({ uid, password, region }) });
    $("uid").value = "";
    $("password").value = "";
    toast("Account added", "ok");
  } catch (err) {
    toast("Add failed: " + err.message, "err");
  } finally {
    btn.disabled = false;
    btn.textContent = "Add Account";
  }
}

async function onCardClick(e) {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const uid = btn.dataset.uid;
  const act = btn.dataset.act;
  const acc = state.accounts[uid] || {};

  if (act === "stop") {
    // nice confirm / cancel popup before stopping the match
    openConfirm({
      title: "Stop the match?",
      text: `Stop the BR match for <b>${esc(acc.name || "this account")}</b> (UID ${esc(uid)})?<br>The bot will stop playing and pinging.`,
      icon: "\u25a0",
      confirmText: "Stop Match",
      onConfirm: async () => {
        toast("Stopping match...");
        try {
          await api(`/api/accounts/${encodeURIComponent(uid)}/stop`, { method: "POST" });
          toast("Match stopped");
        } catch (err) {
          toast("Error: " + err.message, "err");
        }
      },
    });
    return;
  }

  if (act === "remove") {
    openConfirm({
      title: "Remove account?",
      text: `Remove <b>${esc(acc.name || "this account")}</b> (UID ${esc(uid)}) from the panel?`,
      icon: "\u2715",
      warn: true,
      confirmText: "Remove",
      onConfirm: async () => {
        try {
          await api(`/api/accounts/${encodeURIComponent(uid)}`, { method: "DELETE" });
          delete state.accounts[uid];
          render();
          toast("Removed");
        } catch (err) {
          toast("Error: " + err.message, "err");
        }
      },
    });
    return;
  }

  btn.disabled = true;
  try {
    if (act === "start") {
      toast("Starting BR match...", "ok");
      await api(`/api/accounts/${encodeURIComponent(uid)}/start`, { method: "POST" });
    } else if (act === "login") {
      toast("Refreshing details...");
      await api(`/api/accounts/${encodeURIComponent(uid)}/login`, { method: "POST" });
    }
  } catch (err) {
    toast("Error: " + err.message, "err");
  } finally {
    btn.disabled = false;
  }
}

/* ------------------------- websocket ------------------------- */
function connectWS() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);

  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }

    if (msg.type === "snapshot") {
      state.accounts = {};
      (msg.accounts || []).forEach((a) => (state.accounts[a.uid] = a));
      render();
    } else if (msg.type === "account") {
      state.accounts[msg.account.uid] = msg.account;
      render();
    } else if (msg.type === "status") {
      const a = state.accounts[msg.uid];
      if (a) { a.status = msg.status; a.running = ["matchmaking", "in_game"].includes(msg.status); render(); }
    } else if (msg.type === "log") {
      const a = state.accounts[msg.uid];
      if (a) {
        a.logs = a.logs || [];
        a.logs.push({ t: msg.t, msg: msg.msg });
        if (a.logs.length > 60) a.logs = a.logs.slice(-60);
        render();
      }
    } else if (msg.type === "removed") {
      delete state.accounts[msg.uid];
      render();
    }
  };

  ws.onclose = () => setTimeout(connectWS, 1500);
  ws.onerror = () => ws.close();
}

/* ------------------------- init ------------------------- */
async function init() {
  try {
    const r = await api("/api/regions");
    state.regions = r.regions || [];
    const sel = $("region");
    sel.innerHTML = state.regions.map((x) => `<option value="${x}"${x === "ME" ? " selected" : ""}>${x}</option>`).join("");
  } catch (e) {
    $("region").innerHTML = '<option value="ME">ME</option>';
  }

  try {
    const a = await api("/api/accounts");
    (a.accounts || []).forEach((acc) => (state.accounts[acc.uid] = acc));
    render();
  } catch (e) {}

  $("addForm").addEventListener("submit", addAccount);
  $("accounts").addEventListener("click", onCardClick);
  initModal();
  connectWS();
}

document.addEventListener("DOMContentLoaded", init);
