# TODO - FreeFire BR Bot Web Panel

## Round 3 - account stats + stop confirm + reconnect-if-in-match

### A. Account stats (exp gain / total matches / live match timer)
- [x] Track exp_gain accumulator (last_exp + exp_gain) in AccountSession
- [x] Track total_matches, match_started_at, match_info, in_match
- [x] Expose exp_gain / total_matches / match_started_at / in_match in public()
- [x] Persist + restore the new fields in accounts.json
- [x] Update exp on login, match end and periodic refresher
- [x] Frontend: show Exp Gain, Total Matches, Match Time (live timer) stats

### B. Stop confirm/cancel popup
- [x] Add modal markup + styles (confirm/cancel)
- [x] Wire Stop button -> modal -> confirm calls stop API

### C. Reconnect if already in a match (no duplicate match)
- [x] botcore.reconnect_match(): HELLO + pings to an existing match, detect end
- [x] functional_br: match_cb("start"/"end", info) callbacks
- [x] manager.start_match(): if running & in_match -> reconnect+ping; if stale match_info -> reconnect attempt, else new match
- [x] manager._run_reconnect(): reconnect then fall back to normal session

### D. Tests + deliver
- [x] Unit test reconnect_match against mock UDP server
- [x] Offline flow test (manager) for stats + reconnect branch
- [x] Server boots, endpoints 200
- [x] Repackage ff_web_panel.zip + update README
