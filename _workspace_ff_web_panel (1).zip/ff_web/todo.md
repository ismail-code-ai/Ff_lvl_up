# TODO - FreeFire BR Bot Web Panel

## Analysis (round 1 - web conversion)
- [x] Extract and read UDP.zip (lvl.py, message_ids.py, thunderFF_pb2.py)
- [x] Identify auto-BR bug (global ACCOUNT_REGION used instead of per-account region)
- [x] Copy lvl.py -> botcore.py, parameterize region, add callbacks
- [x] Manager + FastAPI server + web UI (add account, details, start match, status)
- [x] Offline flow test + package zip

## Fix round 2 - "[SEND-FAIL] HELLO" / match never enters
- [x] Reproduce: UDP sendto works in sandbox -> error is not network
- [x] Root cause: Windows ProactorEventLoop lacks sock_sendto/sock_recvfrom -> NotImplementedError (empty msg)
- [x] Force WindowsSelectorEventLoopPolicy in botcore.py + server.py; uvicorn loop="asyncio"
- [x] Add loop-agnostic udp_sendto / udp_recvfrom helpers (executor fallback)
- [x] Replace all loop.sock_sendto / sock_recvfrom call sites
- [x] Add HELLO retries (5x) with real error text
- [x] Fix decode_packet KeyError on layouts missing a field code
- [x] Visible in-match PING logging
- [x] Set status "in_game" as soon as HELLO is sent
- [x] Match-end detection: cmd 103/107 + 60s idle -> finish
- [x] Verify auto-restart path in functional_br (break -> reconnect -> send_start_match)

## Tests
- [x] Unit test udp helpers (native + simulated Proactor fallback)
- [x] End-to-end play_game vs mock UDP server: HELLO ok, in_game, ping, THUNDER/SHARMA, match-end return
- [x] Server boots, /api/regions + / return 200

## Deliver
- [x] Update README with fix details
- [x] Repackage ff_web_panel.zip
